<?php
/**
 * application configurations shared by all test types
 */
return [

];
